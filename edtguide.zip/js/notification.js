ChromeNotifications = {
	notifications = [],
	_interval: null,
	Init: function(){
	},
	Start: function(){
		var self = ChromeNotifications;
	},
	Stop: function(){
		var self = ChromeNotifications;
	},
	fetchData: function(){
	},
	addNotification: function(e){
		
	},
	showNotification: function(notification, delay){
		notificatio.show();
		notification.onclick = function(e) {
	},
	
};
